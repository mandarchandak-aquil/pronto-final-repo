import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard02-policy-details-payment-manage',
  templateUrl: './dashboard02-policy-details-payment-manage.component.html',
  styleUrls: ['./dashboard02-policy-details-payment-manage.component.css']
})
export class Dashboard02PolicyDetailsPaymentManageComponent implements OnInit {
  loading : boolean = true;
  constructor() { }

  ngOnInit(): void {
    this.loading = false;
  }

}
