import { Component, OnInit,ViewChild } from '@angular/core';
import { ProductService } from '../../commons/services/product/product.service';
import { DomSanitizer, SafeResourceUrl, SafeUrl} from '@angular/platform-browser';
import { SubjectCallService } from '../../commons/services/subject-call/subject-call.service';
import { ViewportScroller } from '@angular/common';
import { trigger, state, style, animate, transition } from '@angular/animations';
import { Router } from '@angular/router';
@Component({
  selector: 'app-product-mexico-texas-northbound-quote',
  templateUrl: './product-mexico-texas-northbound-quote.component.html',
  styleUrls: ['./product-mexico-texas-northbound-quote.component.css']
})
export class ProductMexicoTexasNorthboundQuoteComponent implements OnInit {
  // @ViewChild('headerspc') headerspc;
  mobileapp;
constructor(public router: Router,public api_sub : SubjectCallService){}
ngOnInit(): void {
  
  // if(this.router.url.slice(-6) == 'mobile'){
  //   this.api_sub.mob  = 1;
  // }else{
  //   this.api_sub.mob  = 0;
  // }
  // this.mobileapp = this.api_sub.mob;
  // if(this.mobileapp == 0){
  //   $('#headerspc').addClass('spcTpHeader');
  // }else{
  //   $('#headerspc').removeClass('spcTpHeader');
  // }
}

ngAfterViewInit()
{
  // if(this.mobileapp == 0){
  //    this.headerspc.nativeElement.classList.add('spcTpHeader')
  //  }else{
  //    this.headerspc.nativeElement.classList.remove('spcTpHeader')
  //  }
    console.log(document.readyState, "document.readyState")
    document.onreadystatechange = function() { 
      if (document.readyState !== "complete") { 
          document.querySelector("body").style.visibility = "hidden"; 
          document.querySelector<HTMLElement>(".site_preloader").style.visibility = "visible"; 
      } else { 
          document.querySelector<HTMLElement>(".site_preloader").style.display = "none"; 
          document.querySelector("body").style.visibility = "visible"; 
      } 
    };


  }
}
