import { DateselectDirective } from './dateselect.directive';

describe('DateselectDirective', () => {
  it('should create an instance', () => {
    const directive = new DateselectDirective();
    expect(directive).toBeTruthy();
  });
});
