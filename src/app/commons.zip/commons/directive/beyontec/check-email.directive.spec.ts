import { CheckEmailDirective } from './check-email.directive';

describe('CheckEmailDirective', () => {
  it('should create an instance', () => {
    const directive = new CheckEmailDirective();
    expect(directive).toBeTruthy();
  });
});
