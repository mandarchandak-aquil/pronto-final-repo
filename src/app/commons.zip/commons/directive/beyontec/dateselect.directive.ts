import { Directive } from '@angular/core';

@Directive({
  selector: '[appDateselect]'
})
export class DateselectDirective {

  constructor() { }

}
