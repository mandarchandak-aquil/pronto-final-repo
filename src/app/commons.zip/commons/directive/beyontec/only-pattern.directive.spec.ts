import { OnlyPatternDirective } from './only-pattern.directive';

describe('OnlyPatternDirective', () => {
  it('should create an instance', () => {
    const directive = new OnlyPatternDirective();
    expect(directive).toBeTruthy();
  });
});
