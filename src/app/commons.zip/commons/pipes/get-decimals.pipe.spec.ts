import { GetDecimalsPipe } from './get-decimals.pipe';

describe('GetDecimalsPipe', () => {
  it('create an instance', () => {
    const pipe = new GetDecimalsPipe();
    expect(pipe).toBeTruthy();
  });
});
