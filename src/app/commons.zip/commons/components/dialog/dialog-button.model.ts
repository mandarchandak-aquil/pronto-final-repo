export interface DialogButtonModel {
  label: string;
}
